<?php

namespace App\Plugins\Telephony\Controllers\Core;

use App\Http\Controllers\Controller;
use Schema;
use Artisan;
use App\Plugins\Telephony\Model\Core\Telephone;
use App\Plugins\Telephony\database\seeds\TelephonySeeder;
use Exception;
use App\Plugins\Telephony\Model\Core\TelephoneDetail;
use Illuminate\Http\Request;

class SettingsController extends Controller {

    public function settings() {
        try {
            $telephone = new Telephone();
            return view("telephone::core.settings", compact('telephone'));
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }

    public function activate() {
        if (env('DB_INSTALL') == 1 && !Schema::hasTable('telephone_providers')) {
            $path = "app" . DIRECTORY_SEPARATOR . "Plugins" . DIRECTORY_SEPARATOR . "Telephony" . DIRECTORY_SEPARATOR . "database" . DIRECTORY_SEPARATOR . "migrations";
            Artisan::call('migrate', [
                '--path' => $path,
                '--force' => true,
            ]);
            $this->seed();
        }
    }

    public function seed() {
        $seeder = new TelephonySeeder();
        $seeder->run();
    }

    public function settingsProvider($short) {
        try {
            $telephones = new Telephone();
            $telephone = $telephones->where('short', $short)->first();
            $details = new TelephoneDetail();
            $name = $telephone->name;
            return view("telephone::$short.settings", compact('details', 'short', 'name'));
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }

    public function postSettingsProvider($short, Request $request) {
        try {
            $requests = $request->except('_token');
            $this->updateDetails($requests, $short);
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }

    public function updateDetails($requests, $short) {
        $details = new TelephoneDetail();
        if (count($requests) > 0) {
            foreach ($requests as $key => $value) {
                $this->deleteDetails($key, $short);
                $details->create([
                    'provider' => $short,
                    'key' => $key,
                    'value' => $value,
                ]);
            }
        }
    }

    public function deleteDetails($key, $short) {
        $details = new TelephoneDetail();
        $detail = $details->where('provider', $short)->where('key', $key)->first();
        if ($detail) {
            $detail->delete();
        }
    }

}
