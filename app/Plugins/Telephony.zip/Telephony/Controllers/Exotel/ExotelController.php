<?php

namespace App\Plugins\Telephony\Controllers\Exotel;

use App\Http\Controllers\Controller;
use App\Plugins\Telephony\Model\Core\Telephone;
use Exception;
use App\Plugins\Telephony\Model\Core\TelephoneDetail;
use Illuminate\Http\Request;

class ExotelController extends Controller {
    
    public function passThrough(Request $request){
        $json = $request->json();
        Log::useDailyFiles(storage_path() . "/logs/info/exotel.log");
        \Log::info($json);
    }
    
}
