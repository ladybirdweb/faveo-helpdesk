<?php

return [
    'telephone-integration' => 'Telephone Integration',
    'integrate'=>'Integrate',
    'provider'=>'Provider',
    'settings'=>'Settings',
    'action'=>'Action',
    'save'=>'Save',
];