<?php

namespace App\Plugins\Zapier\Controllers\HappyFoxChat;

use App\Http\Controllers\Controller;

class ProcessController extends Controller {

    private $request;

    public function __construct($requests) {
        $this->request = $requests['status'];
    }

    public function name() {
        $name = $this->checkArray('name', $this->request);
        return $name;
    }

    public function email() {
        $email = $this->checkArray('email', $this->request);
        return $email;
    }

    public function message() {
        $message = $this->checkArray('message', $this->request);
        return $message;
    }

    public function phone() {
        return "";
    }

    public function phoneCode() {
        return "";
    }

    public function mobile() {
        return "";
    }

    public function channel() {
        $app = $this->checkArray('app', $this->request);
        return $app;
    }

    public function via() {
        return "chat";
    }

    public function subject() {
        return "Chat from HappyFox Chat";
    }

    public function checkArray($key, $array) {
        $value = "";
        if (array_key_exists($key, $array)) {   
            $value = $array[$key];
        }
        return $value;
    }

}
